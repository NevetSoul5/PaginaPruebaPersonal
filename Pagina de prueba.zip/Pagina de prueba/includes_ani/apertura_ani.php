<form action="" method="post">
	<div class="diseno-fuente alineacion-titulo">
				Informacion Anime
	</div>
	<br>
	<div class="diseno-caja diseno-caja-img diseno-aper">
		<a href="" class="item-aper"><img  src="../img/onepunchman.jpg" alt="onepunchman"></a>
		<a href="" class="item-aper"><img  src="../img/shinguekinokyojin.jpg" alt="shinguekinokyojin"></a>
		<a href="" class="item-aper"><img  src="../img/dragonballsuper.jpg" alt="dragonballsuper"></a>	
	</div>
</form>