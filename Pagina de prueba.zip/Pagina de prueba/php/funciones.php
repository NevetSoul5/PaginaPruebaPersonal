<?php ob_start(); ?>
<?php session_start(); ?>
<?php 
	function redirect($location){
		header("location: " . $location);
		exit;
	}
	function query($query){
		global $conexion;
		return mysqli_query($conexion,$query);
	}
	function confirm($resultado){
		global $conexion;
		if(!$resultado){
			die("Fallo en la conexion " . mysqli_error($conexion));
		}
	}
	function fetch_array($query){
		return mysqli_fetch_array($query);
	}
	//es para q el sql no haga injections
	function scape($string){
		global $conexion;
		return mysqli_real_escape_string($conexion, $string);
	}
	function login_user($usename,$usepass){
		global $conexion;
		$query = query("SELECT * FROM users WHERE use_username = '{$usename}'");
		confirm($query);
		while($row = fetch_array($query)){
			$use_id = $row['use_id'];
			$use_nombres = $row['use_nombres'];
			$use_apellidos = $row['use_apellidos'];
			$use_username = $row['use_username'];
			$use_pass = $row['use_pass'];
			$use_img = $row['use_img'];
			$use_rol = $row['use_rol'];
		}
		if($usename === $use_username && $usepass === $use_pass){
				// $_session es para q se ponga esta informacion en la ram pero escondido
				$_SESSION['use_id'] = $use_id;
				$_SESSION['use_username'] = $use_username;
				$_SESSION['use_nombres'] = $use_nombres;
				$_SESSION['use_apellidos'] = $use_apellidos;
				$_SESSION['use_rol'] = $user_rol;
				$_SESSION['use_img'] = $use_img;
				redirect("juegos_user.php");
		}		
		else{			
			redirect("login_error.php");			
		}
	}
?>