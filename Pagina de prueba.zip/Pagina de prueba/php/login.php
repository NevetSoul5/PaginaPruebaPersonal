<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>DarkMastersTM Games&Animes</title>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css"> <!-- Esta linea es para llamar a la regla de normalize que define reglas a todos los navegadores siempre tiene que estar actualizada-->
	<link rel="icon" type="image/png" href="../img/favicon.png">
</head>
<body >
	<header class="header">
		<div class="alineacion diseno-caja">
			<div >
				<a href="../index.html" class="diseno-fuente">DarkMasters™</a>
			</div>
			<div class="diseno-fuente-a espacio-a">
				<a href="animes_user.php">Animes</a>
				<a href="juegos_user.php">Juegos</a>
				<a href="registrar.php" class="sign">Registrar</a>
			</div>
		</div>
	</header>
	<section class="diseno-imagen-lore">
		<div class="alineacion">
			<h1 class="alineacion-titulo titulo-lore">Ingrese su Cuenta</h1>
			<div class="alineacion-iconos">
				<form action="" class="alineacion-label">
					<div class="alineacion-lain">
						<label class="formato-label" for="username">Ingrese su Usuario:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="pass">Ingrese Contraseña:</label>
					</div>
					<br>
				</form>
				<form action="login_cod.php" method="post" class="alineacion-titulo">
					<div >
	                  <input type="text" name="username" id="username"  placeholder="Nombre de usuario" class="input-text" required>
	                </div>
	                <br>          
	                <div >
	                  <input type="password" name="pass" placeholder="Ingrese su contraseña" id="pass" minlength="8" maxlength="16" pattern=".{8,16}" required class="input-text">
	                </div>
	                <br>
	                <div>
	                  <input type="submit" name="login"  value="Inicie Sesion" class="input-sub">	            
					</div>	                               
				</form>				
			</div>
			
		</div>
	</section>
	<footer class="footer">
		<div class="alineacion">
			<div class="diseno-fuente alineacion-titulo">
				Acerca de Nosotros
				<br>
				<hr class="linea-estilo">
			</div>
			<div class="alineacion-redes">
				<p>Aqui encontraras nuestras redes sociales para estar siempre en contacto:</p>
			</div>
			<div class="alineacion-iconos">
				<a href="https://www.facebook.com"><img class="formato-iconos" src="../img/logo-facebook.png" alt="logo-facebook.png"></a>
				<a href="https://www.youtube.com"><img class="formato-iconos" src="../img/logo-youtube.png" alt="logo-youtube.png"></a>
				<a href="https://www.twitch.tv"><img class="formato-iconos" src="../img/logo-twitch.png" alt="img/logo-twitch.png"></a>
			</div>
		</div>
		<div class="alineacion-last">
			©DarkMasters . Todos los derechos reservados CopyRight
		</div>
	</footer>
</body>
</html>