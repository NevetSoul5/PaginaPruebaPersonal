<?php include "funciones.php"; ?>
<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>DarkMastersTM Games&Animes</title>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css"> <!-- Esta linea es para llamar a la regla de normalize que define reglas a todos los navegadores siempre tiene que estar actualizada-->
	<link rel="icon" type="image/png" href="../img/favicon.png">
</head>

<body >	
	<header class="header">
		<div class="alineacion diseno-caja">
			<div >
				<a href="../index.html" class="diseno-fuente">DarkMasters™</a>
			</div>
			<div class="diseno-fuente-a espacio-a">
				<a href="animes_user.php">Animes</a>
				<a href="juegos_user.php">Juegos</a>
				<a href="../admin/index_admin.php">Perfil <?php echo $_SESSION['use_username']; ?></a>
				<a href="../php/logout.php" class="sign">Logout</a>
			</div>			
		</div>
		<div class="alineacion alineacion-juan">
			<a href="animes_user.php?anime=1" class="juan">One Piece</a>
			<a href="animes_user.php?anime=2" class="juan">Dragon Ball</a>
			<a href="animes_user.php?anime=3" class="juan">Shingueki No Kyojin</a>
			<a href="animes_user.php?anime=4" class="juan">Naruto</a>
			<a href="animes_user.php?anime=2" class="juan">Boku No hero</a>
			<a href="animes_user.php?anime=6" class="juan">Claymore</a>
			<a href="animes_user.php?anime=7" class="juan">Nanatsu No Tensai</a>
		</div>
	</header>
	<section class="diseno-imagen-animes">
		<div class="alineacion">
			<?php 
				if(isset($_GET['anime'])){
					$anime = $_GET['anime'];
					switch ($anime) {
		            case '1':
		              include "../includes_ani/onepiece.php";
		              break;
		            case '2':
		              include "../includes_ani/dragonball.php";
		              break;
		            case '3':
		              include "../includes_ani/shinguekinokyojin.php";
		              break;
		            case '4':
		              include "../includes_ani/naruto.php";
		              break;
		            case '5':
		              include "../includes_ani/bokunohero.php";
		              break;
		            case '6':
		              include "../includes_ani/claymore.php";
		              break;
		            case '7':
		           	  include "../includes_ani/nanatsunotensai.php";
		              break;		            
		            default:
		              include "animes_user.php";
		              break;
		          }
				}else{
					include "../includes_ani/apertura_ani.php";
				}
			?>
		</div>
	</section>
	<footer class="footer">
		<div class="alineacion">
			<div class="diseno-fuente alineacion-titulo">
				Acerca de Nosotros
				<br>
				<hr class="linea-estilo">
			</div>
			<div class="alineacion-redes">
				<p>Aqui encontraras nuestras redes sociales para estar siempre en contacto:</p>
			</div>
			<div class="alineacion-iconos">
				<a href="https://www.facebook.com"><img class="formato-iconos" src="../img/logo-facebook.png" alt="logo-facebook.png"></a>
				<a href="https://www.youtube.com"><img class="formato-iconos" src="../img/logo-youtube.png" alt="logo-youtube.png"></a>
				<a href="https://www.twitch.tv"><img class="formato-iconos" src="../img/logo-twitch.png" alt="img/logo-twitch.png"></a>
			</div>
		</div>
		<div class="alineacion-last">
			©DarkMasters . Todos los derechos reservados CopyRight
		</div>
	</footer>
</body>
</html>