<?php include "funciones.php"; ?>
<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>DarkMastersTM Games&Animes</title>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css"> <!-- Esta linea es para llamar a la regla de normalize que define reglas a todos los navegadores siempre tiene que estar actualizada-->
	<link rel="icon" type="image/png" href="../img/favicon.png">
</head>

<body >	
	<header class="header">
		<div class="alineacion diseno-caja">
			<div >
				<a href="../index.html" class="diseno-fuente">DarkMasters™</a>
			</div>
			<div class="diseno-fuente-a espacio-a">
				<a href="animes.php">Animes</a>
				<a href="juegos.php">Juegos</a>
				<a href="login.php" class="sign">Sign up</a>
			</div>
		</div>
	</header>
	<section class="diseno-imagen-lore">
		<div class="alineacion">
			<h1 class="alineacion-titulo titulo-lore">Ingrese sus Datos</h1>
			<div class="alineacion-iconos">
				<form action="" class="alineacion-label">
					<div class="alineacion-lain">
						<label class="formato-label" for="username">Ingrese un Usuario Válido:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="name">Nombres:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="lname">Apellidos:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="fechanac">Ingrese Fecha de Nacimiento:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="email">Ingrese E-mail:</label>
					</div>
					<br>
					<div class="alineacion-lain">
						<label class="formato-label" for="pass">Ingrese Contraseña:</label>
					</div>
					<br>
				</form>
				<form action="" method="post" class="alineacion-titulo">
					<div >
	                  <input type="text" name="username" id="username"  placeholder="Nombre de Usuario" class="input-text" required>
	                </div>
	                <br>
	                <div >
	                  <input type="text" name="name" id="name"  placeholder="Nombres" class="input-text" required>
	                </div>
	                <br>
	                <div >
	                  <input type="text" name="lname" id="lname"  placeholder="Apellidos" class="input-text" required>
	                </div>
	                <br>
	                <div >
	                <input type="date" name="fechanac" id="fechanac" min="1900-01-01" max="2020-01-01" class="input-date" >
	                </div>
	                <br>
	                <div >
	                  <input type="email" name="email" id="email"  placeholder="E-mail" class="input-text" required>
	                </div>
	                <br>
	                <div >
	                  <input type="password" name="pass" placeholder="Ingrese una contraseña" id="pass" minlength="8" maxlength="16" pattern=".{8,16}" required class="input-text">
	                </div>
	                <br>
	                <div>
	                  <input type="submit" name="registrar"  value="Registrar" class="input-sub">
	             	</div>
				</form>
			</div>
			<?php 
                if(isset($_POST['registrar'])){                	
                  $user_username = scape($_POST['username']);
                  $user_names = scape($_POST['name']);
                  $user_lnames = scape($_POST['lname']);
                  $user_fecha_nac = scape($_POST['fechanac']);
                  $user_email  = scape($_POST['email']);
                  $user_pass = scape($_POST['pass']);

                  //randsalt no funciona
                  //$2y$10$poiuytrewqlkjhgfdsamn                 
                  // $user_pass = password_hash($user_pass, PASSWORD_BCRYPT, array('cost' => 10));
                  // echo $user_pass;
                  $query = query("INSERT INTO users(use_username,use_nombres,use_apellidos,use_fecha_nac,use_img,use_email,use_pass,use_rol,use_status) VALUES('{$user_username}','{$user_names}','{$user_lnames}','{$user_fecha_nac}','logoperfil.png','{$user_email}','{$user_pass}','suscriptor','mayor')");
                  confirm($query);
                  redirect("login.php");
                }
            ?>
		</div>
	</section>
	<footer class="footer">
		<div class="alineacion">
			<div class="diseno-fuente alineacion-titulo">
				Acerca de Nosotros
				<br>
				<hr class="linea-estilo">
			</div>
			<div class="alineacion-redes">
				<p>Aqui encontraras nuestras redes sociales para estar siempre en contacto:</p>
			</div>
			<div class="alineacion-iconos">
				<a href="https://www.facebook.com"><img class="formato-iconos" src="../img/logo-facebook.png" alt="logo-facebook.png"></a>
				<a href="https://www.youtube.com"><img class="formato-iconos" src="../img/logo-youtube.png" alt="logo-youtube.png"></a>
				<a href="https://www.twitch.tv"><img class="formato-iconos" src="../img/logo-twitch.png" alt="img/logo-twitch.png"></a>
			</div>
		</div>
		<div class="alineacion-last">
			©DarkMasters . Todos los derechos reservados CopyRight
		</div>
	</footer>
</body>
</html>