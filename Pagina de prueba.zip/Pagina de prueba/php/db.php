<?php 
	$db['db_host']='localhost';
	$db['db_user']='root';
	$db['db_pass']='';
	$db['db_name']='darkmasters';
	foreach ($db as $key => $value) {
		define(strtoupper($key),$value);
	}
	$conexion = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
	$query ="SET NAME utf8";
	mysqli_query($conexion,$query);
	if(!$conexion){
		//echo "estamos conectados";
		die("fallo la conexion" . mysqli_error($conexion)); 
	}
?>