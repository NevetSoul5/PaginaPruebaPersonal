<?php ob_start(); ?>
<?php session_start(); ?>
<?php 
	$_SESSION['user_id'] = null;
	$_SESSION['user_username'] = null;
	$_SESSION['user_name'] = null;
	$_SESSION['user_lnames'] = null;
	$_SESSION['user_rol'] = null;
	$_SESSION['use_img'] = null;
	header("Location: juegos.php");
?>