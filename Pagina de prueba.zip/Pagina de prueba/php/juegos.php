<?php include "funciones.php"; ?>
<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>DarkMastersTM Games&Animes</title>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css"> <!-- Esta linea es para llamar a la regla de normalize que define reglas a todos los navegadores siempre tiene que estar actualizada-->
	<link rel="icon" type="image/png" href="../img/favicon.png">
</head>

<body >	
	<header class="header">
		<div class="alineacion diseno-caja">
			<div >
				<a href="../index.html" class="diseno-fuente">DarkMasters™</a>
			</div>
			<div class="diseno-fuente-a espacio-a">
				<a href="animes.php">Animes</a>
				<a href="juegos.php">Juegos</a>
				<a href="login.php" class="sign">Sign up</a>
			</div>			
		</div>
		<form action="" method="post">
			<div class="alineacion alineacion-juan">
				<a href="juegos.php?juego=1" class="juan">Dota 2</a>
				<a href="juegos.php?juego=2" class="juan">Ace online</a>
				<a href="juegos.php?juego=3" class="juan">Knight Online</a>
				<a href="juegos.php?juego=4" class="juan">WarCraft III</a>
				<a href="juegos.php?juego=5" class="juan">HeartStone</a>
				<a href="juegos.php?juego=6" class="juan">NavyField</a>
				<a href="juegos.php?juego=7" class="juan">NavyField 2</a>
			</div>			
		</form>
	</header>
	<section class="diseno-imagen-juegos">
		<div class="alineacion">
			<?php 
				if(isset($_GET['juego'])){
					$juego = $_GET['juego'];
					switch ($juego) {
		            case '1':
		              include "../includes/dota2.php";
		              break;
		            case '2':
		              include "../includes/aceonline.php";
		              break;
		            case '3':
		              include "../includes/knightonline.php";
		              break;
		            case '4':
		              include "../includes/warcraftiii.php";
		              break;
		            case '5':
		              include "../includes/heartstone.php";
		              break;
		            case '6':
		              include "../includes/navyfield.php";
		              break;
		            case '7':
		           	  include "../includes/navyfield2.php";
		              break;		            
		            default:
		              include "juegos.php";
		              break;
		          }
				}else{
					include "../includes/apertura.php";
				}
			?>
		</div>
	</section>
	<footer class="footer">
		<div class="alineacion">
			<div class="diseno-fuente alineacion-titulo">
				Acerca de Nosotros
				<br>
				<hr class="linea-estilo">
			</div>
			<div class="alineacion-redes">
				<p>Aqui encontraras nuestras redes sociales para estar siempre en contacto:</p>
			</div>
			<div class="alineacion-iconos">
				<a href="https://www.facebook.com"><img class="formato-iconos" src="../img/logo-facebook.png" alt="logo-facebook.png"></a>
				<a href="https://www.youtube.com"><img class="formato-iconos" src="../img/logo-youtube.png" alt="logo-youtube.png"></a>
				<a href="https://www.twitch.tv"><img class="formato-iconos" src="../img/logo-twitch.png" alt="img/logo-twitch.png"></a>
			</div>
		</div>
		<div class="alineacion-last">
			©DarkMasters . Todos los derechos reservados CopyRight
		</div>
	</footer>
</body>
</html>