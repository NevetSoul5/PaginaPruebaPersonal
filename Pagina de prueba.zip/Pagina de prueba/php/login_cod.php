<?php session_start(); ?>
<?php include "db.php"; ?>
<?php include "funciones.php"; ?>
<?php 
	if(isset($_POST['login'])){		
		$use_username = scape($_POST['username']);
		$use_pass = scape($_POST['pass']);		
		login_user($use_username,$use_pass);
	}
?>