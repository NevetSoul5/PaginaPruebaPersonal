<?php include "../php/funciones.php"; ?>
<?php include "../php/db.php"; ?>
<?php 
	global $conexion;
	$query = query("SELECT * FROM users WHERE use_username = '{$_SESSION['use_username']}'");
	confirm($query);
	while($row = fetch_array($query)){		
		$use_img = $row['use_img'];		
	} 
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>DarkMastersTM Games&Animes</title>
	<link rel="stylesheet" type="text/css" href="../css/estilos.css"> <!-- Esta linea es para llamar a la regla de normalize que define reglas a todos los navegadores siempre tiene que estar actualizada-->
	<link rel="icon" type="image/png" href="../img/favicon.png">	
</head>
<body >
	<header class="header">
		<div class="alineacion diseno-caja">
			<div >
				<a href="index.html" class="diseno-fuente">DarkMasters™</a>
			</div>
			<div class="diseno-fuente-admin espacio-admin alineacion-admin">
				<a href="../admin/index_admin.php">Perfil <?php echo $_SESSION['use_username']; ?></a>
				<a href="../admin/index_admin.php" class="formato-img"><img src="../img/<?php echo $use_img; ?>" alt=""></a>
				<a href="../php/logout.php" class="sign">Logout</a>
			</div>
		</div>		
	</header>
	<section class="diseno-imagen-admin">
		<nav class="alineacion-nav">
			<form action="" method="post">
				<div class="diseno-admin-fondo">
					<h1 class="diseno-fuente-admin alineacion-admin">Administrador</h1>
					<ul>
						<li><a href="index_admin.php?admin=1">Perfil</a></li>
						<li><a href="index_admin.php?admin=2">Cambiar Contraseña</a></li>
						<li><a href="index_admin.php?admin=3">Actualizar Datos</a></li>
						<li><a href="../php/juegos_user.php">Ir a Juegos</a></li>
						<li><a href="../php/animes_user.php">Ir a Animes</a></li>
						<li><a href="../php/logout.php">Salir</a></li>
					</ul>
				</div>				
			</form>
			<form action="" method="post" class="diseno-admin-fondo-datos" enctype="multipart/form-data">
				
							<?php 
							if(isset($_GET['admin'])){
							$juego = $_GET['admin'];
							switch ($juego) {
				            case '1':
				              include "includes/perfil.php";
				              break;
				            case '2':
				              include "includes/cambiar_pass.php";
				              break;
				            case '3':
				              include "includes/actualizar_datos.php";
				              break;				           
				            default:
				              include "juegos.php";
				              break;
				          }
						}else{
							include "includes/perfil.php";
						}
					?>
			</form>
		</nav>
	</section>
	<footer class="footer">
		<div class="alineacion">
			<div class="diseno-fuente alineacion-titulo">
				Acerca de Nosotros
				<br>
				<hr class="linea-estilo">
			</div>
			<div class="alineacion-redes">
				<p>Aqui encontraras nuestras redes sociales para estar siempre en contacto:</p>
			</div>
			<div class="alineacion-iconos">
				<a href="https://www.facebook.com"><img class="formato-iconos" src="../img/logo-facebook.png" alt="logo-facebook.png"></a>
				<a href="https://www.youtube.com"><img class="formato-iconos" src="../img/logo-youtube.png" alt="logo-youtube.png"></a>
				<a href="https://www.twitch.tv"><img class="formato-iconos" src="../img/logo-twitch.png" alt="img/logo-twitch.png"></a>
			</div>
		</div>
		<div class="alineacion-last">
			©DarkMasters . Todos los derechos reservados CopyRight
		</div>		
	</footer>
</body>
</html>