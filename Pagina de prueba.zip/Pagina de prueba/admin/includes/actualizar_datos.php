<?php 
	global $conexion;
	$query = query("SELECT * FROM users WHERE use_username = '{$_SESSION['use_username']}'");
	confirm($query);
	while($row = fetch_array($query)){
		$use_id = $row['use_id'];
		$use_nombres = $row['use_nombres'];
		$use_apellidos = $row['use_apellidos'];
		$use_username = $row['use_username'];
		$use_fecha_nac = $row['use_fecha_nac'];
		$use_email = $row['use_email'];
		$use_pass = $row['use_pass'];
		$use_img = $row['use_img'];
		$use_rol = $row['use_rol'];
	} 
?>
<h1 class="alineacion-titulo titulo-lore">Actualizar Datos Usuario</h1>
<br>
<div class="alienacion-iconos alineacion"  style="text-align: center;">
	<form action="" method="post" class="alineacion-titulo" enctype="multipart/form-data">
		
		<label class="formato-label" for="username">Nombre de Usuario:</label>
		<br>
		<br>
		<div >
	        <input type="text" name="username" id="username"  placeholder="Nombre de Usuario" class="input-text"  value="<?php echo $use_username; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="name">Nombres del Usuario:</label>
		<br>
		<br>
	    <div >
	        <input type="text" name="names" id="names"  placeholder="Nombres" class="input-text" value="<?php echo $use_nombres; ?>" required>
	    </div>
	    <br>
	    <label class="formato-label" for="lname">Apellidos del Usuario:</label>
		<br>
		<br>
	    <div >
	        <input type="text" name="lname" id="lname"  placeholder="Apellidos" class="input-text" value="<?php echo $use_apellidos; ?>" required>
	    </div>
	    <br>
	    <label class="formato-label" for="fechanac">Fecha Nacimiento Usuario:</label>
		<br>
		<br>
	    <div >
	        <input type="date" name="fechanac" id="fechanac" min="1900-01-01" max="2020-01-01" class="input-date" value="<?php echo $use_fecha_nac; ?>"disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="email">E-mail del Usuario:</label>
		<br>
		<br>
	    <div >
	        <input type="email" name="email" id="email"  placeholder="E-mail" class="input-text" value="<?php echo $use_email; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="">Avatar Usuario:</label>
		<br>
		<br>
	    <div >
	    	<img src="../img/<?php echo $use_img; ?>" alt="" width="100">
	    	<br>
	    	<input type="file" name="imagen1" id="imagen1">      
	    </div>
	    <br>
	    <div>
	        <input type="submit" name="actualizar"  value="Actualizar" class="input-sub">
	    </div>
	</form>
	<?php 
		if(isset($_POST['actualizar'])){
			$use_nombres = $_POST['names'];
			$use_apellidos = $_POST['lname'];		
			$use_imagen = $_FILES['imagen1']['name'];
			$use_img_temp = $_FILES['imagen1']['tmp_name'];
			move_uploaded_file($use_img_temp, "../img/$use_imagen");
			if(empty($use_imagen)){
				global $conexion;
				$query = query("SELECT * FROM users WHERE use_id = '{$use_id}'");
				confirm($query);					
				while($row = fetch_array($query)){
					$use_imagen = $row['use_img'];
				}
			}
			$query = query("UPDATE users SET use_nombres = '{$use_nombres}', use_apellidos = '{$use_apellidos}', use_img = '{$use_imagen}' WHERE use_id = '{$use_id}'");
			confirm($query);
			redirect("../admin/index_admin.php");
		}
	?>
</div>