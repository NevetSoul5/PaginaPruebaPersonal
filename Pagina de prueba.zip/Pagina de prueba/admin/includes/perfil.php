<?php 	
		global $conexion;
		$query = query("SELECT * FROM users WHERE use_username = '{$_SESSION['use_username']}'");
		confirm($query);
		while($row = fetch_array($query)){
			$use_id = $row['use_id'];
			$use_nombres = $row['use_nombres'];
			$use_apellidos = $row['use_apellidos'];
			$use_username = $row['use_username'];
			$use_fecha_nac = $row['use_fecha_nac'];
			$use_email = $row['use_email'];
			$use_pass = $row['use_pass'];
			$use_img = $row['use_img'];
			$use_rol = $row['use_rol'];
		} ?>

<h1 class="alineacion-titulo titulo-lore">Datos de Usuario</h1>
<br>
<div class="alienacion-iconos alineacion"  style="text-align: center;">
	<form action="" method="post" class="alineacion-titulo">
		
		<label class="formato-label" for="username">Nombre de Usuario:</label>	
		<br>
		<br>
		<div >
	        <input type="text" name="username" id="username"  placeholder="Nombre de Usuario" class="input-text" value="<?php echo $use_username; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="username">Nombres del Usuario:</label>	
		<br>
		<br>
	    <div >
	        <input type="text" name="name" id="name"  placeholder="Nombres" class="input-text" value="<?php echo $use_nombres; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="lname">Apellidos del Usuario:</label>	
		<br>
		<br>
	    <div >
	        <input type="text" name="lname" id="lname"  placeholder="Apellidos" class="input-text" value="<?php echo $use_apellidos; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="fechanac">Fecha Nacimiento Usuario:</label>
		<br>
		<br>
	    <div >
	        <input type="date" name="fechanac" id="fechanac" min="1900-01-01" max="2020-01-01" class="input-date" value="<?php echo $use_fecha_nac; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="email">E-mail del Usuario:</label>	
		<br>
		<br>
	    <div >
	        <input type="email" name="email" id="email"  placeholder="E-mail" class="input-text" value="<?php echo $use_email; ?>" disabled>
	    </div>
	    <br>
	    <label class="formato-label" for="">Avatar Usuario:</label>	
		<br>
		<br>
	    <div >
	    	<img src="../img/<?php echo $use_img; ?>" alt="" width="150">	        
	    </div>
	    <br>	   
	</form>	
</div>
