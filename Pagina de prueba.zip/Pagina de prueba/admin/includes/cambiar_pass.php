<h1 class="alineacion-titulo titulo-lore">Cambiar Contraseña</h1>
<br>
<div class="alienacion-iconos alineacion"  style="text-align: center;">
	<form action="" method="post" class="alineacion-titulo">		
		<label class="formato-label" for="username">Contraseña Actual Usuario:</label>	
		<br>
		<br>
		<div >
	    	<input type="password" name="pass" placeholder="Ingrese una contraseña" id="pass" minlength="8" maxlength="16" pattern=".{8,16}" required class="input-text">
	    </div>
	    <br>
	    <label class="formato-label" for="username">Nueva Contraseña:</label>	
		<br>
		<br>
		<div >
	    	<input type="password" name="pass_nuevo" placeholder="Ingrese una contraseña" id="pass_nuevo" minlength="8" maxlength="16" pattern=".{8,16}" required class="input-text">
	    </div>
	    <br>
	        <input type="submit" name="cambiar" value="Actualizar" class="input-sub">
	    </div>
	    <br>
	    <div style="text-align: center;">
		    <?php 
			if(isset($_POST['cambiar'])){
				$use_pass_ant = $_POST['pass'];
				$use_pass_nuevo = $_POST['pass_nuevo'];
				$query = query("SELECT * FROM users WHERE use_username = '{$_SESSION['use_username']}'");
				confirm($query);
				while($row = fetch_array($query)){				
					$use_pass = $row['use_pass'];				
				}
				if($use_pass_ant === $use_pass){
					$query = query("UPDATE users SET use_pass = '{$use_pass_nuevo}' WHERE use_username = '{$_SESSION['use_username']}'");
					confirm($query);
					echo "<label for='' class='formato-label' style='color:green;'>Cambio de Contraseña correcto</label>";
				}else{
					echo "<label for='' class='formato-label' style='color:red;'>Vuelva a intertar Contraseña incorrecta</label>";
				}			
			}
	    	?>
	    </div>
	
	</form>	
</div>