<br>
<br>
<div class="alineacion alineacion-juan">
	<h1 class="diseno-fuente alineacion-mp">Dota 2</h1>
</div>
<br>
<br>
<div class="alineacion alineacion-juan diseno-aper" style="height: 65vh; overflow: auto;">	
	<p class="parrafo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus, saepe porro totam praesentium numquam laboriosam hic quos impedit. Vero eius consequatur aliquam totam corrupti quos ipsum nulla, dolorum? Dolorem ipsam in sequi reiciendis fugiat, cupiditate, ad incidunt vero cumque, nemo veritatis qui commodi suscipit quam exercitationem, labore rerum minus tenetur. Dolore sequi nemo perspiciatis atque enim et pariatur fuga temporibus repudiandae. Quod sapiente iusto laborum rem quo nam sunt quis, impedit quasi voluptate, blanditiis perferendis dignissimos aut est molestiae porro. Incidunt veniam odio, velit enim quod iure nesciunt aliquam, architecto excepturi sapiente voluptatum facilis sequi sit beatae similique. Placeat, tempore.
		
	</p class="parrafo">
	<iframe width="560" height="315" src="https://www.youtube.com/embed/PqHuUSezPtA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<p class="parrafo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet reprehenderit molestias velit quis assumenda, officiis delectus fuga! Perspiciatis quasi fugiat eum, illo ea! Omnis soluta, sunt voluptatem totam numquam nam fugiat modi sequi, harum vero. Quos omnis sequi iste placeat repellat quo, quisquam, maiores obcaecati maxime velit animi magnam quasi, illum quaerat doloribus nesciunt nulla neque dolorum odio soluta, quae quia saepe. Modi officia beatae quis sint. Ipsum quas totam mollitia quae, accusamus optio eos, eaque quia laborum quo cupiditate iusto perspiciatis nemo blanditiis a sequi quasi voluptatibus, aperiam, ad rerum. Totam rerum, culpa ullam nisi id fuga sed, temporibus.</p>
	<p  class="parrafo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae quasi dolores maxime magni necessitatibus obcaecati consequuntur vel iste placeat eligendi facere ea labore modi accusamus enim, iusto quos delectus numquam beatae molestias reiciendis. Aliquam cumque fugiat sint architecto impedit, id doloribus temporibus ex atque. Explicabo sunt cumque nobis expedita, quos illo obcaecati. Veniam magni, necessitatibus sunt voluptatum ratione ab quas molestias, dolor aspernatur temporibus libero. Facilis voluptate laudantium molestias, beatae asperiores incidunt fuga suscipit numquam debitis esse commodi tempora harum deleniti quas perferendis, inventore excepturi porro ipsam, ducimus. Est id illo perferendis, neque ducimus earum dicta animi quae distinctio, dolorum!</p>
</div>