<form action="" method="post">
	<div class="diseno-fuente alineacion-titulo">
				Juegos Battle Royale
	</div>
	<br>
	<div class="diseno-caja diseno-caja-img diseno-aper">
		<a href="" class="item-aper"><img  src="../img/apexaper.jpg" alt="apexlegends"></a>
		<a href="" class="item-aper"><img  src="../img/fornite.jpg" alt="fornite"></a>
		<a href="" class="item-aper"><img  src="../img/pubg.jpg" alt="pubg"></a>	
	</div>
</form>